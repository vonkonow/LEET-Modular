

#include "integer.h"
#include "fattime.h"


DWORD get_fattime (void)
{
  return 0;
}

